var spaceShip = {
  food:"chocolate",
  drink:"water",
  fuel:125000,
};

document.getElementById("infoShip").innerHTML = "People need" spaceShip.food +' "and"'+ spaceShip.drink + ' ' +"to live, but the Spaceship"+ ' ' +" needs " + shipSpace.fuel + ' ' + "to surive their time in space.";


function check() {
	var check = {
	Chocolate: "never enough",
	Water: "sufficient",
	Fuel: "sufficient",
	supplies: function() {
		return "Chocolate: " + this.chocolate + " | Water: " + this.water + " | Fuel: " + this.fuel;
	}
  }
	document.getElementById("supplies").innerHTML = information.supplies();
}

function mode() {
	var change = document.getElementById("screen"); 
	change.className = "chocolateMode";
}

function normal() {
	var normal = document.getElementsByClassName("chocolateMode")[0];
	normal.className = "";
}










